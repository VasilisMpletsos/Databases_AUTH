-- MySQL dump 10.14  Distrib 5.5.57-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.5.57-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `ID_Course` int(6) unsigned NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID_Course`),
  UNIQUE KEY `ID_Course_UNIQUE` (`ID_Course`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (234,'Ασφάλεια Υπολογιστικών Συστημάτων'),(513,'Βάσεις Δεδομένων'),(1236,'Μικροκυματική Τηλεπισκόπηση'),(1237,'Τεχνικό Σχέδιο'),(1238,'Τηλεπικοινωνιακή Ηλεκτρονική'),(1239,'Συστήματα VLSI'),(2145,'Ευρυζωνικά Δίκτυα'),(2185,'Αναγνώριση Προτύπων'),(2186,'Ψηφιακά Συστήματα 3'),(2187,'Συστήματα Πολυμέσων');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `Name` varchar(40) NOT NULL,
  `Date` datetime NOT NULL,
  `Type` varchar(16) DEFAULT NULL,
  `Org_Name` varchar(40) NOT NULL,
  PRIMARY KEY (`Name`,`Date`,`Org_Name`),
  KEY `Org_Name_idx` (`Org_Name`),
  CONSTRAINT `Event_Org_Name` FOREIGN KEY (`Org_Name`) REFERENCES `student_organization` (`Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES ('Party EESTEC','2019-12-22 22:00:00','Party','EESTEC'),('Racing Drift ','2019-12-08 10:00:00','Racing','Aristotle Racing Team'),('Satelite Workshop Solidworks','2019-12-11 09:00:00','Workshop','Asat'),('Team Presentation','2019-12-09 10:00:00','Presentation','Asat'),('Team Presentation','2019-12-22 10:00:00','Presentation','Aristotle Racing Team');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hardware`
--

DROP TABLE IF EXISTS `hardware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hardware` (
  `ID_HW` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `Type` enum('Sensor','Actuator','PC','Electronics','Mechanical') DEFAULT NULL,
  `Cost` float DEFAULT NULL,
  `Replacement` enum('New','OK','to_be_replaced') DEFAULT NULL,
  `Lifetime` int(11) DEFAULT NULL,
  `ID_Room` int(6) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID_HW`),
  UNIQUE KEY `ID_HW_UNIQUE` (`ID_HW`),
  KEY `ID_Room_idx` (`ID_Room`),
  CONSTRAINT `Hardware_ID_Room` FOREIGN KEY (`ID_Room`) REFERENCES `room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8324 DEFAULT CHARSET=utf8 COMMENT='Cost and lifetime cant be lower than 0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hardware`
--

LOCK TABLES `hardware` WRITE;
/*!40000 ALTER TABLE `hardware` DISABLE KEYS */;
INSERT INTO `hardware` VALUES (1537,'PC',10500,'New',44,2301),(3333,NULL,32.5,'to_be_replaced',30,2301),(5345,'Sensor',4.6,'New',60,1800),(7419,'Mechanical',13500,'to_be_replaced',2,3207),(8323,'Actuator',6,'OK',8,1376);
/*!40000 ALTER TABLE `hardware` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`hardware_BEFORE_INSERT` BEFORE INSERT ON `hardware` FOR EACH ROW
BEGIN
	IF (NEW.Cost < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Cost input';
	END IF;
	IF (NEW.Lifetime < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Lifetime input';
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`hardware_BEFORE_UPDATE` BEFORE UPDATE ON `hardware` FOR EACH ROW
BEGIN
	IF (NEW.Cost < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Cost input';
	END IF;
	IF (NEW.Lifetime < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Lifetime input';
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `hardware to be replaced`
--

DROP TABLE IF EXISTS `hardware to be replaced`;
/*!50001 DROP VIEW IF EXISTS `hardware to be replaced`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hardware to be replaced` (
  `ID` tinyint NOT NULL,
  `Type` tinyint NOT NULL,
  `Cost` tinyint NOT NULL,
  `ID_Room` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `lecture_room`
--

DROP TABLE IF EXISTS `lecture_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lecture_room` (
  `ID_Room` int(6) unsigned NOT NULL,
  UNIQUE KEY `ID_Room_UNIQUE` (`ID_Room`),
  CONSTRAINT `Lecture_ID_Room` FOREIGN KEY (`ID_Room`) REFERENCES `room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecture_room`
--

LOCK TABLES `lecture_room` WRITE;
/*!40000 ALTER TABLE `lecture_room` DISABLE KEYS */;
INSERT INTO `lecture_room` VALUES (1375),(2301),(3001),(3207),(3797);
/*!40000 ALTER TABLE `lecture_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license`
--

DROP TABLE IF EXISTS `license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `license` (
  `License` varchar(16) NOT NULL,
  `Name` varchar(16) DEFAULT NULL,
  `Provider` varchar(500) DEFAULT NULL,
  `Priviledge` enum('Premium','Student','Industrial','Professional') DEFAULT NULL,
  `Expire_Date` date DEFAULT NULL,
  `Allocation_Start` datetime DEFAULT NULL,
  `Allocation_Stop` datetime DEFAULT NULL,
  `Cost` float DEFAULT NULL,
  `ID_Course` int(6) unsigned DEFAULT NULL,
  PRIMARY KEY (`License`),
  UNIQUE KEY `#License_UNIQUE` (`License`),
  KEY `ID_Course_idx` (`ID_Course`),
  CONSTRAINT `License_ID_Course` FOREIGN KEY (`ID_Course`) REFERENCES `course` (`ID_Course`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Licenses should only been held for maximun duration of one week!\nAnd dont allow allocation after expiredate';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license`
--

LOCK TABLES `license` WRITE;
/*!40000 ALTER TABLE `license` DISABLE KEYS */;
INSERT INTO `license` VALUES ('3062-6310-1853','Virtuoso','Cadence','Student','2020-12-21','2019-02-02 12:00:00','2019-02-04 09:00:00',535.72,1239),('7304HFBS','AutoCad','AutoDesk','Industrial','2019-12-21','2019-04-02 09:00:00','2019-04-09 09:00:00',1000.5,1237),('832JF92KA','HFSS','Ansys','Student','2023-12-21','2019-01-10 09:00:00','2019-01-10 23:00:00',30.64,1238),('832JF92KB','HFSS','Ansys','Student','2022-12-21','2019-01-10 23:30:00','2019-01-12 23:30:00',900,1238),('91JQPX83F','MATLAB','Mathworks','Professional','2021-11-17','2018-10-02 10:00:00','2018-10-06 10:00:00',50,2145),('91JQPX84F','MATLAB','Mathworks','Professional','2021-12-21','2018-10-02 10:00:00','2018-10-04 10:00:00',50,2145),('91JQPX85F','MATLAB','Mathworks','Professional','2022-07-04','2018-11-05 10:00:00','2018-11-08 10:00:00',50,2145);
/*!40000 ALTER TABLE `license` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`license_BEFORE_INSERT` BEFORE INSERT ON `license` FOR EACH ROW
BEGIN
	IF ( DATEDIFF(NEW.Allocation_Stop,NEW.Allocation_start) > 7 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'License cant be held more than a week';
    END IF;
	IF ( DATEDIFF(NEW.Allocation_Stop,NEW.Allocation_start) > 7 < 0 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Allocation Stop!';
    END IF;
	IF ( DATEDIFF(NEW.Expire_Date,NEW.Allocation_start) < 0 OR DATEDIFF(NEW.Expire_Date,NEW.Allocation_stop) < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Allocation Start or Stop cant be after Expire Date!';
    END IF;
	IF ( NEW.Cost < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cost cant be lower than 0!';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`license_BEFORE_UPDATE` BEFORE UPDATE ON `license` FOR EACH ROW
BEGIN
	IF ( DATEDIFF(NEW.Allocation_Stop,NEW.Allocation_start) > 7 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'License cant be held more than a week';
    END IF;
	IF ( DATEDIFF(NEW.Allocation_Stop,NEW.Allocation_start) > 7 < 0 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Allocation Stop!';
    END IF;
	IF ( DATEDIFF(NEW.Expire_Date,NEW.Allocation_start) < 0 OR DATEDIFF(NEW.Expire_Date,NEW.Allocation_stop) < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Allocation Start or Stop cant be after Expire Date!';
    END IF;
	IF ( NEW.Cost < 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cost cant be lower than 0!';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `organization_office`
--

DROP TABLE IF EXISTS `organization_office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_office` (
  `ID_Room` int(6) unsigned NOT NULL,
  UNIQUE KEY `ID_Room_UNIQUE` (`ID_Room`),
  CONSTRAINT `Organization_ID_Room` FOREIGN KEY (`ID_Room`) REFERENCES `room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_office`
--

LOCK TABLES `organization_office` WRITE;
/*!40000 ALTER TABLE `organization_office` DISABLE KEYS */;
INSERT INTO `organization_office` VALUES (27),(1800),(2777),(3243),(3722);
/*!40000 ALTER TABLE `organization_office` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professor`
--

DROP TABLE IF EXISTS `professor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `professor` (
  `AEM` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(16) DEFAULT NULL,
  `Last_Name` varchar(25) DEFAULT NULL,
  `ID_Room` int(6) unsigned NOT NULL,
  PRIMARY KEY (`AEM`),
  UNIQUE KEY `AEM_UNIQUE` (`AEM`),
  KEY `ID_Room_idx` (`ID_Room`),
  CONSTRAINT `Professor_Room` FOREIGN KEY (`ID_Room`) REFERENCES `professor_room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=725 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professor`
--

LOCK TABLES `professor` WRITE;
/*!40000 ALTER TABLE `professor` DISABLE KEYS */;
INSERT INTO `professor` VALUES (1,'Θέμης','Διαμαντόπουλος',1375),(7,'Στάυρος','Δοκουζιάννης',1833),(11,'Μάκης','Μπλέτσος',1888),(723,'Άκης','Ζαχαρόπουλος',2002),(724,'Τάκης','Βελέτζας',2201);
/*!40000 ALTER TABLE `professor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professor_feedbacks_lecture_room`
--

DROP TABLE IF EXISTS `professor_feedbacks_lecture_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `professor_feedbacks_lecture_room` (
  `AEM_Prof` int(6) unsigned NOT NULL,
  `ID_Room` int(6) unsigned NOT NULL,
  `Sensors` enum('Very Good','Good','Mediocre','Bad','Very Bad') DEFAULT NULL,
  `Overcrowded` enum('Yes','No') DEFAULT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`AEM_Prof`,`ID_Room`,`Date`),
  KEY `ID_Room_idx` (`ID_Room`),
  CONSTRAINT `AEMProf` FOREIGN KEY (`AEM_Prof`) REFERENCES `professor` (`AEM`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Professor_Feedbacks_ID_Room` FOREIGN KEY (`ID_Room`) REFERENCES `lecture_room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professor_feedbacks_lecture_room`
--

LOCK TABLES `professor_feedbacks_lecture_room` WRITE;
/*!40000 ALTER TABLE `professor_feedbacks_lecture_room` DISABLE KEYS */;
INSERT INTO `professor_feedbacks_lecture_room` VALUES (1,1375,'Good','Yes','2019-08-22'),(1,1375,'Bad','Yes','2019-09-22'),(1,2301,'Good','No','2019-07-13'),(1,2301,'Good','Yes','2019-08-20'),(7,1375,'Bad','No','2019-07-13'),(7,2301,'Very Bad','No','2019-08-08'),(7,3001,'Bad','Yes','2019-08-09'),(11,3207,'Mediocre','No','2019-06-13');
/*!40000 ALTER TABLE `professor_feedbacks_lecture_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professor_room`
--

DROP TABLE IF EXISTS `professor_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `professor_room` (
  `ID_Room` int(6) unsigned NOT NULL,
  UNIQUE KEY `ID_Room_UNIQUE` (`ID_Room`),
  CONSTRAINT `Professor_ID_Room` FOREIGN KEY (`ID_Room`) REFERENCES `room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professor_room`
--

LOCK TABLES `professor_room` WRITE;
/*!40000 ALTER TABLE `professor_room` DISABLE KEYS */;
INSERT INTO `professor_room` VALUES (1375),(1833),(1888),(2002),(2201);
/*!40000 ALTER TABLE `professor_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professor_teaches_course`
--

DROP TABLE IF EXISTS `professor_teaches_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `professor_teaches_course` (
  `AEM_Prof` int(6) unsigned NOT NULL,
  `ID_Course` int(6) unsigned NOT NULL,
  `Lecture_Method` enum('Traditional','Flipped_Classroom','Problem_Based','Flex','Lab_Only') DEFAULT NULL,
  `Hourse_Weekly` int(10) unsigned DEFAULT NULL,
  `Year` year(4) NOT NULL,
  PRIMARY KEY (`Year`,`AEM_Prof`,`ID_Course`),
  KEY `ID_Course_idx` (`ID_Course`),
  KEY `AEM_Professor` (`AEM_Prof`),
  CONSTRAINT `AEM_Professor` FOREIGN KEY (`AEM_Prof`) REFERENCES `professor` (`AEM`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Professor_Teaches_ID_Course` FOREIGN KEY (`ID_Course`) REFERENCES `course` (`ID_Course`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professor_teaches_course`
--

LOCK TABLES `professor_teaches_course` WRITE;
/*!40000 ALTER TABLE `professor_teaches_course` DISABLE KEYS */;
INSERT INTO `professor_teaches_course` VALUES (1,513,'Traditional',2,2016),(11,1236,'Problem_Based',2,2016),(1,513,'Problem_Based',2,2017),(7,2186,'Flex',2,2017),(11,1236,'Problem_Based',2,2017),(1,513,'Flipped_Classroom',4,2018),(7,2186,'Traditional',3,2018),(11,1236,'Flex',2,2018),(1,513,'Traditional',2,2019),(7,2186,'Traditional',3,2019),(11,1236,'Problem_Based',2,2019);
/*!40000 ALTER TABLE `professor_teaches_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `ID_Room` int(6) unsigned NOT NULL,
  `Capacity` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID_Room`),
  UNIQUE KEY `ID_Room_UNIQUE` (`ID_Room`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rooms cant have space 0 or lower (at least a human should be in let the students be outside in the cold :P)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (27,40),(1375,96),(1376,1),(1800,38),(1833,1),(1888,1),(2002,1),(2201,1),(2301,30),(2777,2),(3001,180),(3207,107),(3243,40),(3722,21),(3797,30);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`room_BEFORE_INSERT` BEFORE INSERT ON `room` FOR EACH ROW
BEGIN
	IF ( NEW.Capacity < 0 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Capacity';
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`room_BEFORE_UPDATE` BEFORE UPDATE ON `room` FOR EACH ROW
BEGIN
	IF ( NEW.Capacity < 0 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Capacity';
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `room_requests_supply`
--

DROP TABLE IF EXISTS `room_requests_supply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_requests_supply` (
  `Name_Supply` varchar(45) NOT NULL,
  `ID_Room_Supply` int(6) unsigned NOT NULL,
  `Request_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Name_Supply`,`ID_Room_Supply`),
  KEY `ID_Room_idx` (`ID_Room_Supply`),
  CONSTRAINT `Name` FOREIGN KEY (`Name_Supply`) REFERENCES `supplies` (`Name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ID_Room` FOREIGN KEY (`ID_Room_Supply`) REFERENCES `room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_requests_supply`
--

LOCK TABLES `room_requests_supply` WRITE;
/*!40000 ALTER TABLE `room_requests_supply` DISABLE KEYS */;
INSERT INTO `room_requests_supply` VALUES ('Eraser',3001,'2019-04-01 09:00:00'),('Lamp',2201,'2019-04-14 11:30:00');
/*!40000 ALTER TABLE `room_requests_supply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `see_tutors`
--

DROP TABLE IF EXISTS `see_tutors`;
/*!50001 DROP VIEW IF EXISTS `see_tutors`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `see_tutors` (
  `Year` tinyint NOT NULL,
  `Grade` tinyint NOT NULL,
  `AEM` tinyint NOT NULL,
  `ID_Course` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `AEM` int(6) unsigned NOT NULL,
  `First_Name` varchar(16) DEFAULT NULL,
  `Last_Name` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`AEM`),
  UNIQUE KEY `AEM_UNIQUE` (`AEM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1245,'Στέφανος','Κοντογιάννης'),(5678,'Στέλιος','Μακρής'),(8687,'Βασίλειος','Μπλέτσος'),(18903,'Τάσος','Ληξουργιώτης'),(34567,'Αντώνης','Πέτκας'),(45212,'Αντώνης','Καραφωτάκης');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_has_course`
--

DROP TABLE IF EXISTS `student_has_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_has_course` (
  `AEM_Stud` int(6) unsigned NOT NULL,
  `ID_Course` int(6) unsigned NOT NULL,
  `Tutors` tinyint(1) DEFAULT NULL,
  `Rating` varchar(45) DEFAULT NULL,
  `Grade` int(10) DEFAULT NULL,
  `Year` year(4) NOT NULL,
  PRIMARY KEY (`AEM_Stud`,`ID_Course`,`Year`),
  KEY `ID_Course_idx` (`ID_Course`),
  KEY `AEM_Stud_Course` (`AEM_Stud`),
  CONSTRAINT `AEM_Stud_Course` FOREIGN KEY (`AEM_Stud`) REFERENCES `student` (`AEM`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ID_Course` FOREIGN KEY (`ID_Course`) REFERENCES `course` (`ID_Course`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grade cant be smaller from 0 or greater than 10!(Hope it would)\nAlso tinyint should be 1 or 0 \nwhere 1 specifying that student tutors that course and 0 not!';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_has_course`
--

LOCK TABLES `student_has_course` WRITE;
/*!40000 ALTER TABLE `student_has_course` DISABLE KEYS */;
INSERT INTO `student_has_course` VALUES (1245,234,0,'Very Good',9,2018),(1245,513,0,NULL,9,2018),(1245,1238,0,'Nice!',8,2018),(1245,1239,0,NULL,5,2019),(1245,2145,0,NULL,NULL,2019),(5678,513,1,'Excellent Lectures',9,2016),(5678,1239,0,NULL,9,2019),(5678,2145,0,NULL,3,2018),(5678,2145,0,'At last i passed, Difficult Lesson',5,2019),(18903,1237,0,NULL,NULL,2019),(18903,1239,1,'Smooth Lecture',9,2017),(34567,234,0,NULL,NULL,2016),(34567,513,0,'Almosth There',3,2017),(34567,513,0,'Nice',10,2018),(34567,1238,0,NULL,7,2016),(34567,1239,0,'Nice Lecture',8,2018),(45212,513,0,NULL,2,2016),(45212,513,0,NULL,7,2017),(45212,1238,0,NULL,9,2017),(45212,1239,0,'Excellent',7,2017),(45212,2185,0,NULL,NULL,2019);
/*!40000 ALTER TABLE `student_has_course` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`student_has_course_BEFORE_INSERT` 
BEFORE INSERT ON `student_has_course` FOR EACH ROW
BEGIN
	IF ( NEW.Grade < 0 OR NEW.Grade > 10 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Grade';
	END IF;
    IF ( NEW.Tutors <> 0 AND NEW.Tutors <> 1) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Tutors';
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`student_has_course_BEFORE_UPDATE` BEFORE UPDATE ON `student_has_course` FOR EACH ROW
BEGIN
	IF ( NEW.Grade < 0 OR NEW.Grade > 10 ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Grade';
	END IF;
    IF ( NEW.Tutors <> 0 AND NEW.Tutors <> 1) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong Input for Tutors';
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `student_is_member_student_organization`
--

DROP TABLE IF EXISTS `student_is_member_student_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_is_member_student_organization` (
  `AEM_Stud` int(6) unsigned NOT NULL,
  `Org_Name` varchar(40) NOT NULL,
  PRIMARY KEY (`AEM_Stud`,`Org_Name`),
  KEY `Org_Name_idx` (`Org_Name`),
  KEY `AEM_Stud_Member` (`AEM_Stud`),
  CONSTRAINT `AEM_Stud_Member` FOREIGN KEY (`AEM_Stud`) REFERENCES `student` (`AEM`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Student_Org_Name` FOREIGN KEY (`Org_Name`) REFERENCES `student_organization` (`Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_is_member_student_organization`
--

LOCK TABLES `student_is_member_student_organization` WRITE;
/*!40000 ALTER TABLE `student_is_member_student_organization` DISABLE KEYS */;
INSERT INTO `student_is_member_student_organization` VALUES (1245,'Aristotle Racing Team'),(5678,'EESTEC'),(8687,'Aristotle Racing Team'),(8687,'EESTEC'),(18903,'Asat'),(18903,'EESTEC'),(34567,'BEST');
/*!40000 ALTER TABLE `student_is_member_student_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_organization`
--

DROP TABLE IF EXISTS `student_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_organization` (
  `Name` varchar(40) NOT NULL,
  `Purpose` varchar(10000) DEFAULT NULL,
  `Site` varchar(200) DEFAULT NULL,
  `Establishment_Date` date DEFAULT NULL,
  `ID_Room` int(6) unsigned DEFAULT NULL,
  PRIMARY KEY (`Name`),
  UNIQUE KEY `Name_UNIQUE` (`Name`),
  KEY `ID_Room_idx` (`ID_Room`),
  CONSTRAINT `Organization_Room` FOREIGN KEY (`ID_Room`) REFERENCES `organization_office` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_organization`
--

LOCK TABLES `student_organization` WRITE;
/*!40000 ALTER TABLE `student_organization` DISABLE KEYS */;
INSERT INTO `student_organization` VALUES ('Aristotle Racing Team','Extreme Racing','www.aristotleracingteam.gr','2006-08-01',27),('Aristurtle','Just Racing','www.aristurtle.gr','2015-04-01',3722),('Asat','Aerospace Applications','www.asat.gr','2015-10-01',1800),('BEST','Workshops ','www.best.auth.gr',NULL,3243),('EESTEC','Workshops & Exchange','www.eestec.net','2015-09-01',2777);
/*!40000 ALTER TABLE `student_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplies`
--

DROP TABLE IF EXISTS `supplies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplies` (
  `Name` varchar(45) NOT NULL,
  `Quantity` int(50) DEFAULT NULL,
  `Priority` enum('Urgent','Medium','Low','High') NOT NULL,
  `ID_Room` int(6) unsigned NOT NULL,
  PRIMARY KEY (`Name`,`Priority`,`ID_Room`),
  KEY `ID_Room_idx` (`ID_Room`),
  CONSTRAINT `Supplies_ID_Room` FOREIGN KEY (`ID_Room`) REFERENCES `room` (`ID_Room`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplies`
--

LOCK TABLES `supplies` WRITE;
/*!40000 ALTER TABLE `supplies` DISABLE KEYS */;
INSERT INTO `supplies` VALUES ('Eraser',50,'Low',3001),('Lamp',4,'Urgent',2201),('Pen',100,'Urgent',3207),('Syraptiko',3,'High',3001);
/*!40000 ALTER TABLE `supplies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `urgent_supplies`
--

DROP TABLE IF EXISTS `urgent_supplies`;
/*!50001 DROP VIEW IF EXISTS `urgent_supplies`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `urgent_supplies` (
  `Name` tinyint NOT NULL,
  `Quantity` tinyint NOT NULL,
  `ID_Room` tinyint NOT NULL,
  `First_Name` tinyint NOT NULL,
  `Last_Name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `hardware to be replaced`
--

/*!50001 DROP TABLE IF EXISTS `hardware to be replaced`*/;
/*!50001 DROP VIEW IF EXISTS `hardware to be replaced`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hardware to be replaced` AS select `hardware`.`ID_HW` AS `ID`,`hardware`.`Type` AS `Type`,`hardware`.`Cost` AS `Cost`,`hardware`.`ID_Room` AS `ID_Room` from `hardware` where (`hardware`.`Replacement` = 'to_be_replaced') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `see_tutors`
--

/*!50001 DROP TABLE IF EXISTS `see_tutors`*/;
/*!50001 DROP VIEW IF EXISTS `see_tutors`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `see_tutors` AS select `student_has_course`.`Year` AS `Year`,`student_has_course`.`Grade` AS `Grade`,`student_has_course`.`AEM_Stud` AS `AEM`,`student_has_course`.`ID_Course` AS `ID_Course` from `student_has_course` where (`student_has_course`.`Tutors` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `urgent_supplies`
--

/*!50001 DROP TABLE IF EXISTS `urgent_supplies`*/;
/*!50001 DROP VIEW IF EXISTS `urgent_supplies`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `urgent_supplies` AS select `supplies`.`Name` AS `Name`,`supplies`.`Quantity` AS `Quantity`,`supplies`.`ID_Room` AS `ID_Room`,`professor`.`First_Name` AS `First_Name`,`professor`.`Last_Name` AS `Last_Name` from (`supplies` join `professor` on((`professor`.`ID_Room` = `supplies`.`ID_Room`))) where (`supplies`.`Priority` = 'Urgent') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-20  2:29:41
