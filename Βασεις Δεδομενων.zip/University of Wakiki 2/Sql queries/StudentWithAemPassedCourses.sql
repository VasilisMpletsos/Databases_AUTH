SELECT * FROM mydb.student_has_course
WHERE AEM_Stud = 1245 AND Grade <> ''