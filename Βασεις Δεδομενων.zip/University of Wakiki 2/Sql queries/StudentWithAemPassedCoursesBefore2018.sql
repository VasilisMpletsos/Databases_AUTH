SELECT AEM_Stud AS AEM,Tutors,Grade FROM mydb.student_has_course
WHERE AEM_Stud = 1245 AND Grade <> '' AND Year < 2019